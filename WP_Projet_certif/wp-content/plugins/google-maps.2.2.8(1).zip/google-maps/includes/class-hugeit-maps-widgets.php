<?php

/**
 * Class Hugeit_Maps_Widgets
 */
class Hugeit_Maps_Widgets {

    /**
     * Initialize Huge-IT Google Maps Widgets
     */
    public static function init(){
        register_widget( 'Hugeit_Maps_Widget' );
    }

}