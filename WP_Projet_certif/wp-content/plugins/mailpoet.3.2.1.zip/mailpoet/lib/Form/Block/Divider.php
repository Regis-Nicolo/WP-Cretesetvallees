<?php
namespace MailPoet\Form\Block;

class Divider {

  static function render() {
    return '<hr class="mailpoet_divider" />';
  }
}