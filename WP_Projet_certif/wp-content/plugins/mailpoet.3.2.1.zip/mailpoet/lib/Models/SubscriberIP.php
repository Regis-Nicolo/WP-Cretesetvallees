<?php
namespace MailPoet\Models;

if(!defined('ABSPATH')) exit;

class SubscriberIP extends Model {
  public static $_table = MP_SUBSCRIBER_IPS_TABLE;
}
