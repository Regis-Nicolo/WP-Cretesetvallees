Icons are a subset of FontAwesome
Font Awesome by Dave Gandy - http://fontawesome.io

License: SIL OFL 1.1
URL: http://scripts.sil.org/OFL