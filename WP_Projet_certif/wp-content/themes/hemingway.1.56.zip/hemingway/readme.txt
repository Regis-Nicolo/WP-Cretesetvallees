Copyright
--------------

Hemingway WordPress Theme, Copyright 2014 Anders Norén
Hemingway is distributed under the terms of the GNU GPL v2


Install Steps
--------------

1. Upload the theme
2. Activate the theme


Licenses
--------------

Standard header image license: CC0 1.0 Universal (CC0 1.0) http://creativecommons.org/publicdomain/zero/1.0/

Lato font license : SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

Raleway font license : SIL Open Font License, 1.1 http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

screenshot.png header image license : Public Domain CC0 1.0 Universal (CC0 1.0) http://creativecommons.org/publicdomain/zero/1.0/

screenshot.png post image license : Public Domain CC0 1.0 Universal (CC0 1.0) http://creativecommons.org/publicdomain/zero/1.0/